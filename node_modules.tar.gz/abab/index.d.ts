export function atob(encodedData: string): string | null
export function btoa(stringToEncode: string): string | null
